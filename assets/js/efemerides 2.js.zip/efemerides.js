const efemerides = {
    '05-11': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Dia Lanzamiento Sega Saturn en Norteamérica' },
    '05-12': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana lanzamiento Sega Saturn en Norteamérica' },
    '05-13': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana lanzamiento Sega Saturn en Norteamérica' },
    '05-14': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana lanzamiento Sega Saturn en Norteamérica' },
    '05-15': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana lanzamiento Sega Saturn en Norteamérica' },
    '05-16': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana lanzamiento Sega Saturn en Norteamérica' },
    '05-17': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana lanzamiento Sega Saturn en Norteamérica' },
    '07-08': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Dia Lanzamiento Sega Saturn en España y Europa' },
    '07-09': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana Lanzamiento Sega Saturn en España y Europa' },
    '07-10': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana Lanzamiento Sega Saturn en España y Europa' },
    '07-11': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana Lanzamiento Sega Saturn en España y Europa' },
    '07-12': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana Lanzamiento Sega Saturn en España y Europa' },
    '07-13': { system: 'Lanzamiento Sega Saturn', year: 1995, desc: 'Semana Lanzamiento Sega Saturn en España y Europa' },
    '07-14': { system: 'Lanzamiento MH218', year: 2025, desc: 'Dia Lanzamiento Microhobby 218' },
    '07-15': { system: 'Lanzamiento MH218', year: 2025, desc: 'Semana Lanzamiento Microhobby 218' },
    '07-16': { system: 'Lanzamiento MH218', year: 2025, desc: 'Semana Lanzamiento Microhobby 218' },
    '07-17': { system: 'Lanzamiento MH218', year: 2025, desc: 'Semana Lanzamiento Microhobby 218' },
    '07-18': { system: 'Lanzamiento MH218', year: 2025, desc: 'Semana Lanzamiento Microhobby 218' },
    '07-19': { system: 'Lanzamiento MH218', year: 2025, desc: 'Semana Lanzamiento Microhobby 218' },
    '07-20': { system: 'Lanzamiento MH218', year: 2025, desc: 'Semana Lanzamiento Microhobby 218' },
    '07-21': { system: 'Lanzamiento MH218', year: 2025, desc: 'Semana Lanzamiento Microhobby 218' },
    '11-22': { system: 'Lanzamiento Sega Saturn', year: 1994, desc: 'Dia Lanzamiento Sega Saturn en Japón' },
    '11-23': { system: 'Lanzamiento Sega Saturn', year: 1994, desc: 'Semana Lanzamiento Sega Saturn en Japón' },
    '11-24': { system: 'Lanzamiento Sega Saturn', year: 1994, desc: 'Semana Lanzamiento Sega Saturn en Japón' },
    '11-25': { system: 'Lanzamiento Sega Saturn', year: 1994, desc: 'Semana Lanzamiento Sega Saturn en Japón' },
    '11-26': { system: 'Lanzamiento Sega Saturn', year: 1994, desc: 'Semana Lanzamiento Sega Saturn en Japón' },
    '11-27': { system: 'Lanzamiento Sega Saturn', year: 1994, desc: 'Semana Lanzamiento Sega Saturn en Japón' },
    '11-28': { system: 'Lanzamiento Sega Saturn', year: 1994, desc: 'Semana Lanzamiento Sega Saturn en Japón' },
}
let eventData = "";

/*
const efemerides2 = {
    '01-01': { system: 'Sinclair ZX Spectrum Plus', year: 1984 },
    '01-15': { system: 'Amstrad CPC 464', year: 1986 },
    '01-16': { system: 'Sinclair QL', year: 1984 },
    '01-31': { system: 'Amstrad PCW 9512', year: 1987 },
    '02-01': { system: 'Sinclair ZX80', year: 1980 },
    '02-15': { system: 'FM Towns', year: 1990 },
    '02-20': { system: 'Super Famicom', year: 1990 },
    '02-26': { system: 'Nintendo 3DS', year: 2011 },
    '03-04': { system: 'Sony PlayStation 2', year: 2000 },
    '03-05': { system: 'Sharp X68000', year: 1987 },
    '03-21': { system: 'Nintendo Game Boy Advance', year: 2001 },
    '03-29': { system: 'Nintendo 64', year: 1997 },
    '04-01': { system: 'Bally Astrocade', year: 1978 },
    '04-21': { system: 'Nintendo Game Boy', year: 1989 },
    '04-30': { system: 'Acorn Archimedes', year: 1987 },
    '05-24': { system: 'Magnavox Odyssey', year: 1972 },
    '05-30': { system: 'Commodore 16', year: 1984 },
    '05-31': { system: 'Amiga 3000', year: 1990 },
    '06-01': { system: 'Apple II', year: 1977 }, // Prioritized Apple II for historical significance
    '06-15': { system: 'Apple IIGS', year: 1986 },
    '06-23': { system: 'Nintendo 64', year: 1996 },
    '07-03': { system: 'Nintendo Famicom', year: 1983 },
    '07-06': { system: 'ColecoVision', year: 1982 },
    '07-12': { system: 'NEC PC Engine', year: 1987 },
    '07-16': { system: 'Commodore 64', year: 1982 },
    '07-20': { system: 'Mattel Intellivision', year: 1980 },
    '07-29': { system: 'Magnavox Odyssey 2', year: 1979 },
    '08-03': { system: 'Tandy TRS-80 Model I', year: 1987 },
    '08-06': { system: 'Super Nintendo Entertainment System', year: 1991 },
    '08-11': { system: 'Sega Genesis', year: 1989 },
    '08-12': { system: 'Sega Master System', year: 1986 },
    '08-29': { system: 'NEC TurboGrafx-16', year: 1989 },
    '08-31': { system: 'Sinclair ZX Spectrum 16K-48K', year: 1982 },
    '09-01': { system: 'Amstrad CPC 464 Plus', year: 1990 }, // Prioritized CPC 464 Plus
    '09-09': { system: 'Atari 2600', year: 1977 },
    '09-11': { system: 'Atari Lynx', year: 1989 },
    '09-17': { system: 'Amiga CD32', year: 1993 },
    '09-19': { system: 'Nintendo DS', year: 2004 },
    '09-21': { system: 'PC Engine Duo', year: 1990 },
    '09-23': { system: 'Bandai Playdia', year: 1994 },
    '09-29': { system: 'FM Towns Marty', year: 1993 },
    '10-01': { system: 'Sega Master System', year: 1985 },
    '10-04': { system: '3DO Interactive Multiplayer', year: 1993 },
    '10-06': { system: 'Sega Game Gear', year: 1990 },
    '10-18': { system: 'Nintendo Entertainment System', year: 1985 },
    '10-20': { system: 'Sega Mega Drive', year: 1988 },
    '10-21': { system: 'Game Boy Color', year: 1998 },
    '10-26': { system: 'Amiga 500', year: 1987 },
    '10-27': { system: 'Amiga 2000', year: 1987 },
    '10-30': { system: 'MSX 1', year: 1983 },
    '11-01': { system: 'Atari 5200', year: 1982 }, // Prioritized Atari 5200
    '11-15': { system: 'Microsoft Xbox', year: 2001 },
    '11-18': { system: 'Nintendo GameCube', year: 2001 },
    '11-19': { system: 'Nintendo Wii', year: 2006 },
    '11-22': { system: 'Microsoft Xbox 360', year: 2005 },
    '11-27': { system: 'Sega Dreamcast', year: 1998 },
    '11-30': { system: 'Atari Jaguar', year: 1993 }, // Prioritized Atari Jaguar
    '12-01': { system: 'Dragon 32-64', year: 1982 }, // Prioritized Dragon 32-64
    '12-03': { system: 'Sony PlayStation', year: 1994 },
    '12-12': { system: 'Sega Mega-CD', year: 1991 },
    '12-17': { system: 'Sega Dreamcast', year: 1999 }, // Prioritized Sega Dreamcast (1999) over Sony PSP
    '12-19': { system: 'Casio Loopy', year: 1995 }
};
*/

function getEfemeridesCSS() {
    // Get current date or test date from URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    const testDate = urlParams.get('test_date');
    const currentDate = testDate ? new Date(testDate) : new Date();

    console.log('currentDate.getDate():', currentDate.getDate()); // Debería ser 14
        console.log('currentDate.getMonth():', currentDate.getMonth()); // Debería ser 6 (julio, meses van de 0-11)

    console.log('testdate:', testDate); // Depuración
    console.log('currentdate:', currentDate); // Depuración

    // Format date for comparison (MM-DD)
    console.log('toISOString:', currentDate.toISOString());
    const monthDay = currentDate.toISOString().slice(5, 10);

    console.log('monthDay:', monthDay); // Depuración

    let cssFile = 'default.css';

    // Check if current date matches an efemérides
    if (efemerides[monthDay]) {
        const system = efemerides[monthDay].system;
        cssFile = system.toLowerCase().replace(/[^a-z0-9-]/g, '_') + '.css';
        
        // Obtener el año actual
        const currentYear = new Date().getFullYear();

        // Calcular la diferencia en años
        const yearsDifference = currentYear - efemerides[monthDay].year;
        
        switch (yearsDifference) 
        {
            case 0:
                eventData = "¡Está pasando AHORA!: " + efemerides[monthDay].desc;
                break;
            case 1:
                eventData = "¡Primer Aniversario!: " + efemerides[monthDay].desc;
                break;
            default:
                eventData = "¡" + yearsDifference + " Aniversario!: " + efemerides[monthDay].desc;
                break;
        }

    }

    return cssFile;
}

// Function to apply the CSS file dynamically
function applyEfemeridesCSS() {
    const cssFile = getEfemeridesCSS();
    const linkElement = document.createElement('link');
    linkElement.rel = 'stylesheet';
    linkElement.href = `https://metsuke.com/assets/css/z_ef_${cssFile}`; // Adjust path as needed
    document.head.appendChild(linkElement);

    // Selecciona el h2 dentro del header
    const h2Element = document.querySelector('header h2');
    // Asigna el contenido de eventData al texto del h2
    h2Element.textContent = eventData;

}

// Run when the DOM is fully loaded
document.addEventListener('DOMContentLoaded', applyEfemeridesCSS);